#!/bin/bash

source settings.sh
bash $XL_HOME/init.sh